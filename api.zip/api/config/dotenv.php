<?php
// Headers
$ORIGIN = "*";
$CONTENT_TYPE = "application/json; charset=UTF-8";
$POST_METHOD = "POST";
$MAX_AGE = 3600;
$ALLOWED_HEADERS = "Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With";


// Development MYSQL
$HOST = "localhost";
$DB_NAME = "fuelalert_db";
$USERNAME = "root";
$PASSWORD = "";

// Production
// $HOST = "";
// $DB_NAME = "fuelalert_db";
// $USERNAME = "root";
// $PASSWORD = "";

// SQLITE
$DBSEED = "/fuelalert_db.sqlite3";